//@line 4 "/Volumes/BruceDeuce/src/esr38l/browser/locales/en-US/firefox-l10n.js"

//@line 6 "/Volumes/BruceDeuce/src/esr38l/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
